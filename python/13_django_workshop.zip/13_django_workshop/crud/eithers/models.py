from django.db import models

class Question(models.Model):
    title = models.CharField(max_length=50)
    choice_a = models.CharField(max_length=50)
    choice_b = models.CharField(max_length=50)


#필수 데이터 question, content, choice
class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    content = models.CharField(max_length=200)

    #선택지를 강제하는 필드가 CHOICES
    CHOICE_A = 'BLUE'
    CHOICE_B = 'RED'

    CHOICES = [
        (CHOICE_A, 'BLUE'),
        (CHOICE_B, 'Red'),
    ]

    # BLUE or RED 하나만 저장할 것.
    choice = models.CharField( #문자열을 쓸 것이기에 CharField는 동일하고 선택지를 내가 지정할 것.
        max_length=4,
        choices=CHOICES,  #CHOICES안의 둘 중 하나만 저장하게 디비에서 강제하는 것.
        default= CHOICE_A, #선택 안할 시 자동으로 A 선택  없어도 됨
    )


#두번째 방법
'''
    #1번에 대한 answer가 얼마나 있는지
    #0번에 대한 answer가 얼마나 있는지

class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    content = models.CharField(max_length=200)
    #True: Blue, False: Red
    # choice = models.BooleanField()

    # 1:Blue, 0: Red
    choice = models.IntegerField()  #사용자의 선택만 저장
'''