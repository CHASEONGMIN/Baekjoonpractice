from django.db import models
from django.contrib.auth.models import AbstractUser

# 팔로우 기능 구현을 위한 모델 세팅
class User(AbstractUser):
    followings = models.ManyToManyField('self', symmetrical=False, related_name='followers')
    
