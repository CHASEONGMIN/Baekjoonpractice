from django.shortcuts import render, redirect, get_object_or_404
from .models import Question, Answer
from .forms import QuestionForm, AnswerForm
from django.views.decorators.http import require_GET, require_http_methods, require_POST

@require_GET
def index(request):
    questions = Question.objects.order_by('?') #랜덤으로 정렬된 Question 목록을 가져옴
    context = {
        'questions': questions,
    }
    return render(request, 'eithers/index.html', context)


@require_http_methods(["GET", "POST"])
def create(request):

    if request.method == 'GET':
        form = QuestionForm()
    else: # POST:            
        form = QuestionForm(request.POST) 
        if form.is_valid():  
            article = form.save()      
            return redirect('eithers:index')
    context = {'form': form,} 
    return render(request, 'eithers/create.html', context)


@require_GET
def detail(request, pk):
    question = get_object_or_404(Question, pk=pk)
    answer_form = AnswerForm()
    answers = either.answer_set.all()
    context = {
        'question' : question,
        'answer_form' : answer_form,
        'answers' : answers,
    }
    return render(request, 'eithers/detail.html', context)

@require_POST
def comments_create(request, pk):

    question = get_object_or_404(Question, pk=pk)
    answer_form = AnswerForm(request.POST)
    if answer_form.is_valid():
        answer = answer_form.save(commit=False)
        answer.question = question
        answer.save()
        return redirect('eithers:detail', question.pk)
    context = {
        'answer_form': answer_form,
        'question': question,
    }
    return render(request, 'eithers/detail.html', context)
  

    