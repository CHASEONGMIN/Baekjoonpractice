#수정하고자하는 form 가져올 것
from django.contrib.auth.forms import UserChangeForm
from django.contrib.auth import get_user_model

class CustomUserChangeForm(UserChangeForm):

    #메타 클래스 오버라이딩  (모델과 필드들만 해주면 됨 - 필드가 너무 많았음)
    class Meta:
        model = get_user_model()
        fields = ('email', 'first_name', 'last_name')

