from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm, UserChangeForm, PasswordChangeForm
#세션 발급받기 위해 사용
from django.contrib.auth import login as auth_login, logout as auth_logout, update_session_auth_hash, get_user_model #이름 login 안 겹치게 만들어야 하므로
from django.views.decorators.http import require_POST, require_http_methods, require_GET
from django.contrib.auth.decorators import login_required
from .forms import CustomUserChangeForm

@require_GET
def index(request):
    # user list 뽑아서 index.html에 전달  (article에서 한 것처럼!!)
    User = get_user_model()  #장고에서 유저 모델은 무조건 get_user_model()만 써야함!!
    users = User.objects.order_by('-pk')
    context = {
        'users' : users,
    }
    return render(request, 'accounts/index.html', context)

@require_http_methods(['GET', 'POST'])
def login(request):
    if request.user.is_authenticated:
        return redirect('articles:index')

    if request.method == 'POST': # ID, PWD 확인 후 session 발급
        form = AuthenticationForm(request, request.POST)
        #Session 발급
        if form.is_valid():
            auth_login(request, form.get_user())
            # 만약 next 파라미터가 있으면 next로 보낸다. (이전에 있던 곳 등)
            # 없으면 articles:index로 보낸다. (홈으로)  매우 중요!!
            return redirect(request.GET.get('next') or 'articles:index') # 단축평가 활용 A OR B 모두 참이면 A 
            
            #redirect => 주소창에 엔터치는것과 동일 => GET 요청 !! (405 에러 주의)

    else:  # GET => 로그인 form 제공
        form = AuthenticationForm()
    context = {
        'form': form,
    }
    return render(request, 'accounts/login.html', context)

@require_POST
def logout(request):
    auth_logout(request)
    return redirect('articles:index')

# 4. 회원가입 생성
@require_http_methods(['GET', 'POST'])
def signup(request): #회원가입
    if request.user.is_authenticated:
        return redirect('articles:index')

    if request.method == 'POST': #회원가입 후 로그인
        form = UserCreationForm(request.POST)  #얘만 request만 받음 2개가 아니라
        if form.is_valid():
            # 회원가입 후 자동으로 로그인을 해주기 위한 아래 두줄!!!
            user = form.save() #user instance 반환
            auth_login(request, user) #로그인
            return redirect('accounts:login')  #홈으로

    else: # GET 회원가입 form 제공
        form = UserCreationForm()
    context = {'form':form}
    return render(request, 'accounts/signup.html', context)

#5. 탈퇴
@require_POST
def delete(request):
    if request.user.is_authenticated:        
        auth_logout(request) # 로그아웃후에 계정을 삭제하여 세션도 같이 날려주자
        request.user.delete()
    return redirect('articles:index')

# 6. 업데이트 
@login_required # /accounts/login/ 이 기본 위치로 보내주는 역할!
@require_http_methods(['GET', 'POST'])
def update(request):
    if request.method == 'POST': #유저 정보 변경 요청
        form = CustomUserChangeForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('articles:index')

    else: # GET => 수정 Form 제공, 유저에대한 정보가 미리 있어야 함(instance로).
        form = CustomUserChangeForm(instance = request.user)
    context = {'form':form}
    return render(request, 'accounts/update.html', context)

@login_required
@require_http_methods(['GET', 'POST'])
def password(request):
    if request.method == 'POST': #비밀번호 변경 로직
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid(): #작성한 비밀번호 2개가 일치하는지 등등
            form.save()
            update_session_auth_hash(request, form.user)
            return redirect('articles:index')
    else: # GET => 비밀번호 변경 Form 제공
        form = PasswordChangeForm(request.user) #첫 인자로 유저 정보 받음
    context = {'form': form}
    return render(request, 'accounts/password.html', context)
